const menuMusic = new Audio('sounds/menu_music.mp3');
menuMusic.loop = true;
menuMusic.volume = 0.6;
window.addEventListener('load', () => { setTimeout(() => menuMusic.play(), 4000); });