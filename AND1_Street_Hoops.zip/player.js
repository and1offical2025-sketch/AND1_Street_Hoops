let player = {
  build: "Sharpshooter",
  attributes: {
    threePoint: 85, layup: 70, dribbling: 75,
    speed: 80, agility: 75, vertical: 70, stamina: 90
  },
  rep: 0, badges: []
};