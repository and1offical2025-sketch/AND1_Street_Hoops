const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let stamina = 100;
let rep = 0;
function drawCourt() {
  ctx.fillStyle = "#dcb57a";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#000";
  ctx.fillText("1v1 Court", canvas.width / 2 - 50, 40);
}
function updateStamina(change) { stamina = Math.max(0, Math.min(100, stamina + change)); }
let startY = 0; let endY = 0;
canvas.addEventListener('touchstart', e => { startY = e.touches[0].clientY; });
canvas.addEventListener('touchend', e => {
  endY = e.changedTouches[0].clientY;
  if (startY - endY > 100) shoot();
  else if (endY - startY > 100) stepBack();
});
function shoot() { if (stamina < 20) return; console.log("Shoot!"); updateStamina(-20); }
function stepBack() { console.log("Step back!"); updateStamina(-10); }
function gameLoop() {
  drawCourt();
  ctx.fillStyle = "#fff";
  ctx.fillText("Stamina: " + stamina, 20, 20);
  requestAnimationFrame(gameLoop);
}
function startGame() {
  document.getElementById('main-menu').classList.add('hidden');
  canvas.classList.remove('hidden');
  gameLoop();
}
window.startGame = startGame;